﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanjie27
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            //Console.WriteLine("Выполнил студент группы ИСП.20А");
            //Console.WriteLine("Мелега Алексей");
            //Console.WriteLine("Задание №17");
            //List<int> numbers = new List<int>();
            //Console.WriteLine("Введите количество чисел");
            //int n = int.Parse(Console.ReadLine());
            //Console.WriteLine("Введите числа: ");
            //for (int i = 0; i < n; i++)
            //{
            //    int v = int.Parse(Console.ReadLine());
            //    numbers.Add(v);
            //}
            //int min = numbers.Min();
            //int max = numbers.Max();

            //int minInd = Array.IndexOf(numbers, min);
            //int maxInd = Array.IndexOf(numbers, max);

            //int minIndLast = Array.LastIndexOf(numbers, min);
            //int maxIndLast = Array.LastIndexOf(numbers, max);

            //int indBeg, indLast;
            //if (minInd < maxInd)
            //    (indBeg, indLast) = (minInd, maxIndLast);
            //else
            //    (indBeg, indLast) = (maxInd, minIndLast);

            Console.WriteLine("Задание №19");
            List<int> numbers = new List<int>();
            Console.WriteLine("Введите количество чисел");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите числа: ");
            for (int i = 0; i < n; i++)
            {
                int v = int.Parse(Console.ReadLine());
                numbers.Add(v);
            }
            Console.WriteLine("Введите число К: ");
            int k = int.Parse(Console.ReadLine());
            List<int> numbers1 = new List<int>();
            numbers.RemoveAll(x => x % 3 == 0);
            foreach (var item in numbers)
            {
                Console.WriteLine(item);
            }
            
            Console.WriteLine("Задание №22");
            List<int> numbers2 = new List<int>();
            Console.WriteLine("Введите количество чисел");
            int n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите числа: ");
            for (int i = 0; i < n2; i++)
            {
                int v = int.Parse(Console.ReadLine());
                numbers2.Add(v);
            }
            List<int> numbers3 = new List<int>();
            foreach (var x in numbers2)
                if (!numbers3.Contains(x))
                {
                    numbers3.Add(x);
                }
            Console.WriteLine(numbers3.Count);
            Console.ReadKey();
        }
    }
}
